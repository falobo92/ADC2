import { ESTADO_COLORS, ESTADO_ORDER } from '../config/constants.js';

// ===== CONTROLADOR DE DATOS =====
export class DataController {
    constructor(appState, dataManager, filterManager, chartManager, dataAnalyzer, notificationManager) {
        this.state = appState;
        this.dataManager = dataManager;
        this.filterManager = filterManager;
        this.chartManager = chartManager;
        this.dataAnalyzer = dataAnalyzer;
        this.notifications = notificationManager;
    }
    
    // Procesamiento de archivos
    async handleFileUpload(files) {
        if (!files.length) return;
        
        const result = await this.dataManager.handleFileUpload(files);
        
        if (result.success) {
            this.filterManager.updateDynamicSelectors();
            this.initializeView();
        }
        
        return result;
    }
    
    // Inicialización de vista
    initializeView() {
        if (this.state.allRawData.length > 0) {
            const weeks = this.dataManager.getUniqueValues('Semana')
                .map(w => String(w))
                .sort((a, b) => parseInt(b) - parseInt(a));
            
            const weekSelect = document.getElementById('weekSelect');
            if (weekSelect && weeks.length > 0) {
                weekSelect.value = weeks[0];
                this.filterManager.updateDaySelector(weeks[0], true);
            }
            
            this.applyFiltersAndAnalyze();
            document.getElementById('noDataMessage').classList.add('hidden');
        } else {
            this.clearDisplayElements();
            document.getElementById('noDataMessage').classList.remove('hidden');
            document.getElementById('analysisContainer').classList.add('hidden');
            document.getElementById('subcontractView').classList.add('hidden');
            this.filterManager.enableControls(false);
        }
    }
    
    // Aplicación de filtros y análisis
    applyFiltersAndAnalyze() {
        if (this.state.isProcessing) return;
        
        this.state.isProcessing = true;
        
        try {
            if (this.state.allRawData.length === 0) {
                this.clearDisplayElements();
                document.getElementById('analysisContainer').classList.add('hidden');
                document.getElementById('subcontractView').classList.add('hidden');
                document.getElementById('noDataMessage').classList.remove('hidden');
                this.filterManager.enableControls(false);
                return;
            }
            
            this.filterManager.enableControls(true);
            
            if (this.state.currentFilteredData.length > 0) {
                this.state.previousStats = this.getCurrentStats();
            }
            
            const filters = this.filterManager.getCurrentFilters();
            
            this.state.currentFilteredData = this.applyPunctualFilters(filters);
            this.state.currentEvolutionData = this.applyEvolutionFilters(filters);
            
            if (filters.subcontract !== 'all') {
                this.renderSubcontractView(filters.subcontract);
            } else {
                this.renderMainView();
            }
            
            this.updateHeaderStats();
        } finally {
            setTimeout(() => {
                this.state.isProcessing = false;
            }, 50);
        }
    }
    
    // Filtros para vistas puntuales
    applyPunctualFilters(filters) {
        return this.state.allRawData.filter(item => {
            if (filters.week !== 'all' && String(item.Semana) !== filters.week) return false;
            if (filters.day && item.FechaReporte !== filters.day) return false;
            if (filters.tematica !== 'all' && item.Tematica !== filters.tematica) return false;
            if (filters.item !== 'all' && item.Item !== filters.item) return false;
            if (filters.state !== 'all' && item.Estado !== filters.state) return false;
            if (filters.person !== 'all') {
                const personMatch = item.Elaborador === filters.person || 
                                  item.Revisor === filters.person || 
                                  item.Coordinador === filters.person;
                if (!personMatch) return false;
            }
            return true;
        });
    }
    
    // Filtros para vista de evolución
    applyEvolutionFilters(filters) {
        return this.state.allRawData.filter(item => {
            if (filters.tematica !== 'all' && item.Tematica !== filters.tematica) return false;
            if (filters.item !== 'all' && item.Item !== filters.item) return false;
            if (filters.state !== 'all' && item.Estado !== filters.state) return false;
            if (filters.person !== 'all') {
                const personMatch = item.Elaborador === filters.person || 
                                  item.Revisor === filters.person || 
                                  item.Coordinador === filters.person;
                if (!personMatch) return false;
            }
            return true;
        });
    }
    
    // Renderizado de vista principal
    renderMainView() {
        document.getElementById('analysisContainer').classList.remove('hidden');
        document.getElementById('subcontractView').classList.add('hidden');
        this.analyzeAndDisplayData();
    }
    
    // Renderizado de vista de subcontratos
    renderSubcontractView(subcontractName) {
        document.getElementById('analysisContainer').classList.add('hidden');
        document.getElementById('subcontractView').classList.remove('hidden');
        this.state.currentSubcontractName = subcontractName;
        this.renderActiveSubcontractTab();
    }
    
    // Análisis y display de datos
    analyzeAndDisplayData() {
        const stateAnalysis = this.dataAnalyzer.analyzeStates(this.state.currentFilteredData);
        this.renderActiveMainTab(stateAnalysis);
    }
    
    // Renderizado de pestaña principal activa
    renderActiveMainTab(stateAnalysis) {
        switch (this.state.currentMainTab) {
            case 'dashboard':
                this.updateAllCharts(stateAnalysis);
                break;
            case 'evolution':
                this.renderEvolutionTab();
                break;
            case 'subcontracts':
                this.renderSubcontractsTab();
                break;
            case 'roles':
                this.analyzeRoles();
                break;
            case 'reports':
                this.renderReportsSection();
                break;
        }
    }
    
    // Actualización de gráficos
    updateAllCharts(stateAnalysis) {
        this.chartManager.destroyAllCharts();
        
        const chartConfigs = [
            { key: 'total', canvasId: 'chartTotal', cardId: 'chartTotalCard', legendId: 'legendTotal' },
            { key: 'ADC', canvasId: 'chartADC', cardId: 'chartADCCard', legendId: 'legendADC' },
            { key: 'PAC', canvasId: 'chartPAC', cardId: 'chartPACCard', legendId: 'legendPAC' }
        ];
        
        chartConfigs.forEach(config => {
            if (stateAnalysis[config.key] && Object.keys(stateAnalysis[config.key]).length > 0) {
                this.createChartWithLegend(config.canvasId, config.key, stateAnalysis[config.key], config.cardId, config.legendId);
            }
        });
    }
    
    // Creación de gráfico con leyenda
    createChartWithLegend(canvasId, chartKey, data, cardId, legendId) {
        const chart = this.chartManager.createDonutChart(canvasId, chartKey, data);
        if (chart) {
            this.populateLegendTable(legendId, data, chartKey);
            document.getElementById(cardId).classList.remove('hidden');
        }
    }
    
    // Poblado de tabla de leyenda
    populateLegendTable(tableId, data, chartKey) {
        const tableBody = document.querySelector(`#${tableId} tbody`);
        if (!tableBody) return;
        
        tableBody.innerHTML = '';
        const total = Object.values(data).reduce((acc, val) => acc + val, 0);
        
        // Ordenar los estados según ESTADO_ORDER
        const orderedStates = ESTADO_ORDER.filter(state => data.hasOwnProperty(state));
        
        orderedStates.forEach(state => {
            const count = data[state];
            const percentage = total > 0 ? ((count / total) * 100).toFixed(1).replace('.', ',') : '0,0';
            const color = ESTADO_COLORS[state] || ESTADO_COLORS.default;
            
            const row = tableBody.insertRow();
            row.innerHTML = `
                <td style="display: flex; align-items: center; gap: 8px;">
                    <div style="width: 12px; height: 12px; background-color: ${color}; border-radius: 2px; flex-shrink: 0;"></div>
                    <span style="font-weight: normal;">${state}</span>
                </td>
                <td style="text-align: center; font-weight: 700;">${count}</td>
                <td style="text-align: center; font-weight: 700;">${percentage}%</td>
            `;
            
            // Hacer la fila interactiva
            row.style.cursor = 'pointer';
            row.addEventListener('click', () => {
                // Llamar al método showQuestionsInModal del DashboardApp
                if (window.app && window.app.showQuestionsInModal) {
                    window.app.showQuestionsInModal(state, chartKey);
                }
            });
            
            // Efectos hover
            row.addEventListener('mouseenter', () => {
                row.style.backgroundColor = 'var(--bg-tertiary)';
            });
            
            row.addEventListener('mouseleave', () => {
                row.style.backgroundColor = '';
            });
        });
    }
    
    // Actualización de estadísticas del header
    updateHeaderStats() {
        const stats = this.getCurrentStats();
        
        const elements = {
            'headerTotalItems': stats.total,
            'headerTotalADC': stats.adc,
            'headerTotalPAC': stats.pac,
            'headerIncorporated': stats.incorporated,
            'headerEditorial': stats.editorial
        };
        
        Object.entries(elements).forEach(([id, value]) => {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = value;
            }
        });
    }
    
    // Obtención de estadísticas actuales
    getCurrentStats() {
        const data = this.state.currentFilteredData;
        return {
            total: data.length,
            adc: data.filter(item => item.Documento === 'ADC').length,
            pac: data.filter(item => item.Documento === 'PAC').length,
            incorporated: data.filter(item => item.Estado === 'Incorporada').length,
            editorial: data.filter(item => item.Estado === 'En revisor editorial').length
        };
    }
    
    // Limpieza de elementos de display
    clearDisplayElements() {
        const elementsToClear = [
            'headerTotalItems', 'headerTotalADC', 'headerTotalPAC',
            'headerIncorporated', 'headerEditorial'
        ];
        
        elementsToClear.forEach(id => {
            const element = document.getElementById(id);
            if (element) element.textContent = '0';
        });
    }
    
    // Métodos placeholder para funcionalidades futuras
    renderEvolutionTab() {
        // Implementar lógica de evolución
        if (window.app && window.app.updateEvolutionView) {
            // Asegurar que los datos de evolución estén actualizados
            const filters = this.filterManager.getCurrentFilters();
            this.state.currentEvolutionData = this.applyEvolutionFilters(filters);
            
            window.app.updateEvolutionView();
        } else {
            console.error('Función updateEvolutionView no está disponible');
        }
    }
    
    renderSubcontractsTab() {
        // Implementar lógica de subcontratos
        this.renderSubcontractsOverview();
    }
    
    analyzeRoles() {
        // Implementar análisis de roles
        console.log('Análisis de roles en desarrollo');
    }
    
    renderReportsSection() {
        // Implementar sección de reportes
        console.log('Sección de reportes en desarrollo');
    }
    
    renderActiveSubcontractTab() {
        // Implementar pestaña activa de subcontratos
        const currentTab = this.state.currentTab || 'overview';
        this.renderSubcontractTabContent(currentTab);
    }
    
    // Nueva implementación para subcontratos
    renderSubcontractsOverview() {
        const data = this.state.currentFilteredData;
        const subcontracts = this.getSubcontractsData(data);
        
        // Actualizar estadísticas generales
        this.updateSubcontractStats(subcontracts);
        
        // Renderizar grid de subcontratos
        this.renderSubcontractsGrid(subcontracts);
        
        // Renderizar gráfico de evolución temporal
        this.renderSubcontractEvolutionChart(subcontracts);
    }
    
    getSubcontractsData(data) {
        const subcontractsMap = new Map();
        
        data.forEach(item => {
            const subcontract = item.Subcontrato || 'Sin Subcontrato';
            if (!subcontractsMap.has(subcontract)) {
                subcontractsMap.set(subcontract, {
                    name: subcontract,
                    total: 0,
                    incorporated: 0,
                    editorial: 0,
                    inProgress: 0,
                    items: []
                });
            }
            
            const subData = subcontractsMap.get(subcontract);
            subData.total++;
            subData.items.push(item);
            
            if (item.Estado === 'Incorporada') {
                subData.incorporated++;
            } else if (item.Estado === 'En revisor editorial') {
                subData.editorial++;
            } else {
                subData.inProgress++;
            }
        });
        
        return Array.from(subcontractsMap.values());
    }
    
    updateSubcontractStats(subcontracts) {
        const totalSubcontracts = subcontracts.length;
        const completedSubcontracts = subcontracts.filter(sub => 
            sub.incorporated === sub.total && sub.total > 0
        ).length;
        const inProgressSubcontracts = subcontracts.filter(sub => 
            sub.inProgress > 0 || sub.editorial > 0
        ).length;
        
        const totalItems = subcontracts.reduce((acc, sub) => acc + sub.total, 0);
        const totalIncorporated = subcontracts.reduce((acc, sub) => acc + sub.incorporated, 0);
        const overallProgress = totalItems > 0 ? Math.round((totalIncorporated / totalItems) * 100) : 0;
        
        // Actualizar elementos del DOM
        const elements = {
            'totalSubcontracts': totalSubcontracts,
            'completedSubcontracts': completedSubcontracts,
            'inProgressSubcontracts': inProgressSubcontracts,
            'overallProgress': `${overallProgress}%`
        };
        
        Object.entries(elements).forEach(([id, value]) => {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = value;
            }
        });
    }
    
    renderSubcontractsGrid(subcontracts) {
        const gridContainer = document.getElementById('subcontractsGrid');
        if (!gridContainer) return;
        
        const gridHTML = subcontracts.map(subcontract => {
            const progressPercentage = subcontract.total > 0 ? 
                Math.round((subcontract.incorporated / subcontract.total) * 100) : 0;
            
            const statusClass = subcontract.incorporated === subcontract.total && subcontract.total > 0 ? 
                'completed' : subcontract.inProgress > 0 || subcontract.editorial > 0 ? 
                'in-progress' : 'pending';
            
            return `
                <div class="subcontract-card" onclick="viewSubcontractDetails('${subcontract.name}')">
                    <div class="subcontract-header">
                        <h4>${subcontract.name}</h4>
                        <span class="subcontract-status ${statusClass}">
                            ${statusClass === 'completed' ? 'Completado' : 
                              statusClass === 'in-progress' ? 'En Progreso' : 'Pendiente'}
                        </span>
                    </div>
                    <div class="subcontract-stats">
                        <div class="stat-item">
                            <span class="stat-label">Total:</span>
                            <span class="stat-value">${subcontract.total}</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Incorporadas:</span>
                            <span class="stat-value completed">${subcontract.incorporated}</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">En Editorial:</span>
                            <span class="stat-value editorial">${subcontract.editorial}</span>
                        </div>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${progressPercentage}%"></div>
                        <span class="progress-text">${progressPercentage}%</span>
                    </div>
                </div>
            `;
        }).join('');
        
        gridContainer.innerHTML = gridHTML;
    }
    
    renderSubcontractEvolutionChart(subcontracts) {
        // Implementar gráfico de evolución temporal para subcontratos
        const canvas = document.getElementById('subcontractEvolutionChart');
        if (!canvas) return;
        
        // Por ahora, mostrar un mensaje de desarrollo
        const container = canvas.parentElement;
        if (container) {
            container.innerHTML = '<p>Gráfico de evolución temporal por subcontrato en desarrollo.</p>';
        }
    }
    
    renderSubcontractTabContent(tabName) {
        const tabContent = document.getElementById(`tab-${tabName}`);
        if (!tabContent) return;
        
        switch (tabName) {
            case 'overview':
                this.renderSubcontractOverview();
                break;
            case 'details':
                this.renderSubcontractDetails();
                break;
            case 'timeline':
                this.renderSubcontractTimeline();
                break;
        }
    }
    
    renderSubcontractOverview() {
        const container = document.getElementById('subcontractProgressContainer');
        if (!container) return;
        
        const subcontractName = this.state.currentSubcontractName;
        const subcontractData = this.state.currentFilteredData.filter(item => 
            item.Subcontrato === subcontractName
        );
        
        if (subcontractData.length === 0) {
            container.innerHTML = '<p>No hay datos disponibles para este subcontrato.</p>';
            return;
        }
        
        const stats = this.getSubcontractStats(subcontractData);
        const progressPercentage = stats.total > 0 ? 
            Math.round((stats.incorporated / stats.total) * 100) : 0;
        
        container.innerHTML = `
            <div class="subcontract-overview">
                <h3>${subcontractName}</h3>
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-list"></i></div>
                        <div class="stat-content">
                            <h4>Total Items</h4>
                            <span class="stat-value">${stats.total}</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                        <div class="stat-content">
                            <h4>Incorporadas</h4>
                            <span class="stat-value completed">${stats.incorporated}</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-clock"></i></div>
                        <div class="stat-content">
                            <h4>En Editorial</h4>
                            <span class="stat-value editorial">${stats.editorial}</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-percentage"></i></div>
                        <div class="stat-content">
                            <h4>Progreso</h4>
                            <span class="stat-value">${progressPercentage}%</span>
                        </div>
                    </div>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${progressPercentage}%"></div>
                    <span class="progress-text">${progressPercentage}%</span>
                </div>
            </div>
        `;
    }
    
    getSubcontractStats(data) {
        return {
            total: data.length,
            incorporated: data.filter(item => item.Estado === 'Incorporada').length,
            editorial: data.filter(item => item.Estado === 'En revisor editorial').length,
            inProgress: data.filter(item => 
                item.Estado !== 'Incorporada' && item.Estado !== 'En revisor editorial'
            ).length
        };
    }
    
    renderSubcontractDetails() {
        const container = document.getElementById('tab-details');
        if (!container) return;
        
        container.innerHTML = '<p>Detalles del subcontrato en desarrollo.</p>';
    }
    
    renderSubcontractTimeline() {
        const container = document.getElementById('tab-timeline');
        if (!container) return;
        
        container.innerHTML = '<p>Cronograma del subcontrato en desarrollo.</p>';
    }
} 